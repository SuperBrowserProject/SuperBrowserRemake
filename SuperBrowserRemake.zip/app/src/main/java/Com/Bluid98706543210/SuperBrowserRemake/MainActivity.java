package Com.Bluid98706543210.SuperBrowserRemake;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.app.Activity;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.widget.ImageView;
import android.widget.HorizontalScrollView;
import android.widget.EditText;
import java.util.Timer;
import java.util.TimerTask;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.view.View;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private double a = 0;
	private String b = "";
	private String f = "";
	private String h = "";
	private double sair_x2 = 0;
	private double loading = 0;
	private boolean m = false;
	private double n = 0;
	private double cont = 0;
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private SeekBar barra_carregamento;
	private WebView webview;
	private ImageView settings;
	private ImageView image_voltar;
	private ImageView imagen_avancar;
	private ImageView recarregar_pagina;
	private HorizontalScrollView barra_da_url;
	private ImageView home;
	private ImageView ir;
	private EditText url;
	private ImageView imageview_zoom_mais;
	private ImageView imageview_zoom_menos;
	
	private TimerTask tm;
	private Intent gread = new Intent();
	private AlertDialog.Builder dg;
	private SharedPreferences file;
	private SharedPreferences hdjddj;
	private SharedPreferences test;
	private Intent cjcjcj = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize();
		initializeLogic();
	}
	
	private void initialize() {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		barra_carregamento = (SeekBar) findViewById(R.id.barra_carregamento);
		webview = (WebView) findViewById(R.id.webview);
		webview.getSettings().setJavaScriptEnabled(true);
		webview.getSettings().setSupportZoom(true);
		settings = (ImageView) findViewById(R.id.settings);
		image_voltar = (ImageView) findViewById(R.id.image_voltar);
		imagen_avancar = (ImageView) findViewById(R.id.imagen_avancar);
		recarregar_pagina = (ImageView) findViewById(R.id.recarregar_pagina);
		barra_da_url = (HorizontalScrollView) findViewById(R.id.barra_da_url);
		home = (ImageView) findViewById(R.id.home);
		ir = (ImageView) findViewById(R.id.ir);
		url = (EditText) findViewById(R.id.url);
		imageview_zoom_mais = (ImageView) findViewById(R.id.imageview_zoom_mais);
		imageview_zoom_menos = (ImageView) findViewById(R.id.imageview_zoom_menos);
		dg = new AlertDialog.Builder(this);
		file = getSharedPreferences("file", Activity.MODE_PRIVATE);
		hdjddj = getSharedPreferences("xjxjxj", Activity.MODE_PRIVATE);
		test = getSharedPreferences("test", Activity.MODE_PRIVATE);
		
		webview.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				barra_carregamento.setVisibility(View.VISIBLE);
				a = 0;
				tm = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								barra_carregamento.setProgress((int)a);
								if (a == 101) {
									a = 1;
								}
								else {
									a++;
								}
							}
						});
					}
				};
				_timer.scheduleAtFixedRate(tm, (int)(200), (int)(200));
				b = webview.getUrl();
				f = _url;
				url.setText(_url);
				webview.setVisibility(View.GONE);
				file.edit().putString(String.valueOf((long)(n)), _url).commit();
				n++;
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				tm.cancel();
				barra_carregamento.setVisibility(View.GONE);
				h = webview.getUrl();
				if (b.equals(h) && !f.equals(h)) {
					gread.setAction(Intent.ACTION_VIEW);
					gread.setData(Uri.parse(f));
					startActivity(gread);
				}
				url.setText(_url);
				webview.setVisibility(View.VISIBLE);
				hdjddj.edit().putString(String.valueOf((long)(cont)), _url).commit();
				cont++;
				super.onPageFinished(_param1, _param2);
			}
		});
		
		settings.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				gread.setClass(getApplicationContext(), SettingsActivity.class);
				startActivity(gread);
				finish();
			}
		});
		
		image_voltar.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				webview.goBack();
			}
		});
		
		imagen_avancar.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				webview.goForward();
			}
		});
		
		recarregar_pagina.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				if (loading == 1) {
					webview.stopLoading();
				}
				else {
					webview.loadUrl(webview.getUrl());
					SketchwareUtil.showMessage(getApplicationContext(), "pagina recarregada com sucesso.");
				}
			}
		});
		
		home.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				webview.setVisibility(View.GONE);
				webview.stopLoading();
				url.setText("");
				webview.loadUrl("https://www.google.com.br/");
			}
		});
		
		ir.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				if (url.getText().toString().equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "campo vazio.....");
				}
				else {
					if (url.getText().toString().contains("Http") || url.getText().toString().contains("http")) {
						webview.loadUrl(url.getText().toString());
					}
					else {
						webview.loadUrl("https://www.google.com.br/search?q=".concat(url.getText().toString()));
					}
				}
			}
		});
		
		imageview_zoom_mais.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				webview.zoomIn();
			}
		});
		
		imageview_zoom_menos.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				webview.zoomOut();
			}
		});
	}
	private void initializeLogic() {
		webview.loadUrl("https://www.google.com.br");
		url.setShowSoftInputOnFocus(false);
		 webview.getSettings().setSavePassword(false);
		cont = 0;
		while(true) {
			if (hdjddj.getString(String.valueOf((long)(cont)), "").equals("")) {
				break;
			}
			else {
				cont++;
			}
		}
		if (webview.getUrl().equals("")) {
			SketchwareUtil.showMessage(getApplicationContext(), "campo vazio.....");
		}
		else {
			if (webview.getUrl().contains("Http") || webview.getUrl().contains("http")) {
				webview.loadUrl(webview.getUrl());
			}
			else {
				webview.loadUrl("https://www.google.com.br/url?url=https://m.youtube.com/%3Fgl%3DBR%26hl%3Dpt&rct=j&sa=U&ved=2ahUKEwib7q-Up_HaAhXBl5AKHXHiDmsQjjgwAHoECAMQAw&q=you+rube&usg=AOvVaw1vHeKB_aTVtqSZVwa7PWwV".concat(webview.getUrl()));
			}
		}
	}
	
	@Override
	public void onBackPressed() {
		if (webview.canGoBack()) {
			webview.goBack();
		}
		else {
			finish();
		}
	}
	
	@Override
	public void onStart() {
		super.onStart();
		if (file.getString("a", "").equals("1")) {
			linear1.setBackgroundColor(0xFF212121);
			linear2.setBackgroundColor(0xFF212121);
		}
		else {
			linear1.setBackgroundColor(Color.TRANSPARENT);
			linear2.setBackgroundColor(Color.TRANSPARENT);
		}
	}
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
