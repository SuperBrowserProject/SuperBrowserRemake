package Com.Bluid98706543210.SuperBrowserRemake;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.app.Activity;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import android.view.View;

public class HistoricoActivity extends Activity {
	
	
	private double n = 0;
	private double c = 0;
	private double cont = 0;
	
	private ArrayList<HashMap<String, Object>> list = new ArrayList<>();
	private ArrayList<Double> a = new ArrayList<>();
	private ArrayList<String> b = new ArrayList<>();
	
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private ImageView sair;
	private TextView textview3;
	private ImageView excluir_historico;
	private ListView listview2;
	
	private Intent it = new Intent();
	private SharedPreferences hdjddj;
	private SharedPreferences file;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.historico);
		initialize();
		initializeLogic();
	}
	
	private void initialize() {
		
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		sair = (ImageView) findViewById(R.id.sair);
		textview3 = (TextView) findViewById(R.id.textview3);
		excluir_historico = (ImageView) findViewById(R.id.excluir_historico);
		listview2 = (ListView) findViewById(R.id.listview2);
		hdjddj = getSharedPreferences("xjxjxj", Activity.MODE_PRIVATE);
		file = getSharedPreferences("file", Activity.MODE_PRIVATE);
		
		sair.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				it.setClass(getApplicationContext(), SettingsActivity.class);
				startActivity(it);
				finish();
			}
		});
		
		excluir_historico.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				
			}
		});
	}
	private void initializeLogic() {
		cont = 0;
		while(true) {
			if (hdjddj.getString(String.valueOf((long)(cont)), "").equals("")) {
				break;
			}
			else {
				b.add(hdjddj.getString(String.valueOf((long)(cont)), ""));
				cont++;
			}
		}
		listview2.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_list_item_1, b));
	}
	
	@Override
	public void onStart() {
		super.onStart();
		if (file.getString("a", "").equals("1")) {
			linear9.setBackgroundColor(0xFF212121);
			linear8.setBackgroundColor(0xFF212121);
			linear7.setBackgroundColor(0xFF212121);
			listview2.setBackgroundColor(0xFF9E9E9E);
		}
		else {
			linear9.setBackgroundColor(Color.TRANSPARENT);
			linear8.setBackgroundColor(Color.TRANSPARENT);
			linear7.setBackgroundColor(Color.TRANSPARENT);
			listview2.setBackgroundColor(Color.TRANSPARENT);
		}
	}
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
