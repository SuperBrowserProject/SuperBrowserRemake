package Com.Bluid98706543210.SuperBrowserRemake;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.app.Activity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.Switch;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import android.widget.CompoundButton;
import android.view.View;

public class SettingsActivity extends Activity {
	
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private TextView textview_settings;
	private ImageView voltar;
	private LinearLayout linear8;
	private LinearLayout linear5;
	private LinearLayout linear4;
	private ImageView imageview4;
	private Switch switch1;
	private ImageView historico;
	private TextView djxudu;
	private ImageView imageview2;
	private TextView textview3;
	private LinearLayout linear6;
	
	private SharedPreferences file;
	private Intent it = new Intent();
	private SharedPreferences test;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.settings);
		initialize();
		initializeLogic();
	}
	
	private void initialize() {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		textview_settings = (TextView) findViewById(R.id.textview_settings);
		voltar = (ImageView) findViewById(R.id.voltar);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		switch1 = (Switch) findViewById(R.id.switch1);
		historico = (ImageView) findViewById(R.id.historico);
		djxudu = (TextView) findViewById(R.id.djxudu);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		textview3 = (TextView) findViewById(R.id.textview3);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		file = getSharedPreferences("file", Activity.MODE_PRIVATE);
		test = getSharedPreferences("test", Activity.MODE_PRIVATE);
		
		voltar.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				it.setClass(getApplicationContext(), MainActivity.class);
				startActivity(it);
				finish();
			}
		});
		
		switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					file.edit().putString("a", "1").commit();
					linear1.setBackgroundColor(Color.TRANSPARENT);
					linear2.setBackgroundColor(0xFF212121);
					linear3.setBackgroundColor(0xFF212121);
					voltar.setBackgroundColor(Color.TRANSPARENT);
					switch1.setBackgroundColor(0xFF212121);
				}
				else {
					file.edit().putString("a", "0").commit();
					linear1.setBackgroundColor(Color.TRANSPARENT);
					linear2.setBackgroundColor(Color.TRANSPARENT);
					linear3.setBackgroundColor(Color.TRANSPARENT);
					voltar.setBackgroundColor(Color.TRANSPARENT);
					switch1.setBackgroundColor(Color.TRANSPARENT);
				}
			}
		});
		
		historico.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				it.setClass(getApplicationContext(), HistoricoActivity.class);
				startActivity(it);
				finish();
			}
		});
		
		djxudu.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				it.setClass(getApplicationContext(), HistoricoActivity.class);
				startActivity(it);
				finish();
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				it.setClass(getApplicationContext(), Tela2Activity.class);
				startActivity(it);
				finish();
			}
		});
		
		textview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				it.setClass(getApplicationContext(), Tela2Activity.class);
				startActivity(it);
				finish();
			}
		});
	}
	private void initializeLogic() {
	}
	
	@Override
	public void onStart() {
		super.onStart();
		if (file.getString("a", "").equals("1")) {
			linear1.setBackgroundColor(Color.TRANSPARENT);
			linear2.setBackgroundColor(0xFF212121);
			linear3.setBackgroundColor(0xFF212121);
			voltar.setBackgroundColor(Color.TRANSPARENT);
			switch1.setBackgroundColor(Color.TRANSPARENT);
		}
		else {
			linear1.setBackgroundColor(Color.TRANSPARENT);
			linear2.setBackgroundColor(Color.TRANSPARENT);
			linear3.setBackgroundColor(Color.TRANSPARENT);
			voltar.setBackgroundColor(Color.TRANSPARENT);
			switch1.setBackgroundColor(Color.TRANSPARENT);
		}
	}
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
